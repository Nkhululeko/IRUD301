﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class BasicPlayingStrategy : iPlayingStrategy
    {
        private readonly IVideo i_video;

        public BasicPlayingStrategy(IVideo video)
        {
            i_video = video;
        }

        public void playVideo()
        {
            i_video.Play();
            Console.WriteLine("Using basic video playing strategy and having limited advertisements appear while video is playing.");
        }
    }
}
