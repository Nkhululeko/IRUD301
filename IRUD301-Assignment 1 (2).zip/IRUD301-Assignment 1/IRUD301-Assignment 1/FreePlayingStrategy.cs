﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class FreePlayingStrategy : iPlayingStrategy
    {
        private readonly IVideo i_video;

        public FreePlayingStrategy(IVideo video)
        {
            i_video = video;
        }

        public void playVideo()
        {
            i_video.Play();
            Console.WriteLine("Using free video playing strategy and having a lot of advertisements appear while video is playing.");
        }
    }
}
