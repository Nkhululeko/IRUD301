﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Using the strategy pattern to play different types of videos
            IVideo musicVideo = new MusicVideos();
            iPlayingStrategy premiumPlan = new PremiumPlayingStrategy(musicVideo);
            premiumPlan.playVideo();

            IVideo educationalVideo = new EducationalVideos();
            iPlayingStrategy basicPlan = new BasicPlayingStrategy(educationalVideo);
            basicPlan.playVideo();

            IVideo reactionVideo = new ReactionVideos();
            iPlayingStrategy freePlan = new FreePlayingStrategy(reactionVideo);
            freePlan.playVideo();

            Console.WriteLine();

            // Using the factory pattern to create videos
            IVideoFactory musicVideoFactory = new MusicVideoFactory();
            musicVideoFactory.CreateVideos();

            IVideoFactory eduVideoFactory = new EduVideoFactory();
            eduVideoFactory.CreateVideos();

            IVideoFactory reactionVideoFactory = new ReactionVideoFactory();
            reactionVideoFactory.CreateVideos();

            Console.ReadLine();
        }
    }
}
