﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class PremiumPlayingStrategy : iPlayingStrategy
    {
        private readonly IVideo i_video;

        public PremiumPlayingStrategy(IVideo video)
        {
            i_video = video;
        }

        public void playVideo()
        {
            i_video.Play();
            Console.WriteLine("Using premium video playing strategy and having no advertisements appear while video is playing.");
        }
    }
}
