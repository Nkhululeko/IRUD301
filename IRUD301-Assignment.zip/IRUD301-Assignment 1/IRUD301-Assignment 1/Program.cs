﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Using the strategy pattern to play different types of videos
            Watch musicVideo = new Watch(new MusicVideos());
            musicVideo.watch();

            Watch educationalVideo = new Watch(new EducationalVideos());
            educationalVideo.watch();

            Watch reactionVideo = new Watch(new ReactionVideos());
            reactionVideo.watch();

            // Using the factory pattern to create videos
            IVideoFactory musicVideoFactory = new MusicVideoFactory();
            musicVideoFactory.CreateVideos();

            IVideoFactory eduVideoFactory = new EduVideoFactory();
            eduVideoFactory.CreateVideos();

            IVideoFactory reactionVideoFactory = new ReactionVideoFactory();
            reactionVideoFactory.CreateVideos();

            Console.ReadLine();
        }
    }
}
