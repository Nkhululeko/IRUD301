﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class Watch
    {
        private IVideo _video;

        public Watch(IVideo video) 
        {
            this._video = video;
        }

        public void watch() 
        {
            Console.WriteLine(_video.Play());
        }
    }
}
