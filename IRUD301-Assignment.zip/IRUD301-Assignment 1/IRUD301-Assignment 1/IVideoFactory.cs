﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{ 
    // Factory interface
    internal interface IVideoFactory
    {
        void CreateVideos();
    }
}
