﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    // Concrete Strategy
    internal class EducationalVideos : IVideo
    {
        public void Play()
        {
            Console.WriteLine("Play the educational video at a HD resolution...");
        }
    }
}
