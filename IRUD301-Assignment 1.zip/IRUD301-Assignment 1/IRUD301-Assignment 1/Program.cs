﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Using the strategy pattern to play different types of videos
            IVideo musicVideo = new MusicVideos();
            musicVideo.Play();

            IVideo educationalVideo = new EducationalVideos();
            educationalVideo.Play();

            IVideo reactionVideo = new ReactionVideos();
            reactionVideo.Play();

            // Using the factory pattern to create videos
            IVideoFactory musicVideoFactory = new MusicVideoFactory();
            musicVideoFactory.CreateVideos();

            IVideoFactory eduVideoFactory = new EduVideoFactory();
            eduVideoFactory.CreateVideos();

            IVideoFactory reactionVideoFactory = new ReactionVideoFactory();
            reactionVideoFactory.CreateVideos();

            Console.ReadLine();
        }
    }
}
