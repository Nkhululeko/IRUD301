﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_1
{
    // Concrete Strategy
    internal class MusicVideos : IVideo
    {
        public void Play()
        {
            Console.WriteLine("Playing the music video at an Ultra HD resolution...");
        }
    }
}
